# Jejak Balik — Logo Pack

Original identity created for the Jejak Balik product, October 2026.

## Start here

- `logos/logo.svg`: primary horizontal wordmark.
- `logos/mark.svg`: compact return-path symbol.
- `logos/jejak-balik-*-forest.svg`: primary green family.
- `logos/jejak-balik-*-dark.svg`: dark single-color family.
- `logos/jejak-balik-*-light.svg`: light single-color family.
- `logos/jejak-balik-*-reverse.svg`: cream with a honey trace dot for dark surfaces.
- PNG widths: 256, 512, 1024, 2048. Mark sizes: 32, 64, 128, 256, 512.
- Favicon SVG, PNG, ICO and apple touch icon are at the archive root.
- `fonts/`: Plus Jakarta Sans WOFF2 and TTF weights 400–800, plus its SIL Open Font License.
- `logos/LICENSE-Lucide.txt`: icon attribution retained with the brand system.
- `logos/tokens.json`: exact colors, spacing, typography and motion values.
- `BRAND_SYSTEM.md`: practical application guidance.

Use forest on cream and reverse on forest. Keep proportions and original colors. Preserve at least 8 units of clear space around a 64-unit mark. Minimum standalone mark: 20 CSS px. Minimum horizontal lockup: 128 CSS px. Use the dedicated favicon at 16 px. SVG wordmarks contain editable vector outlines and do not need fonts to display; install the included licensed TTFs when editing document text.

Supporting line: Mengalirkan kembali nilai elektronik.

The original returning path and origin node were designed for this project. No external logo or reference screenshot is included as brand identity.
